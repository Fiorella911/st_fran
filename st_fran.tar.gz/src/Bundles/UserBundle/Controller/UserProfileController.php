<?php

namespace Bundles\UserBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;


class UserProfileController extends Controller
{
    public function showProfileAction()
    {
        $user = $this->get('security.context')->getToken()->getUser();
        
        return $this->render('BundlesUserBundle:UserProfile:userProfile.html.twig', ['user' => $user]);
    }
    
    
    public function editProfileAction()
    {
        $request = Request::createFromGlobals();
        $editUserProfile = new User;
//        if (!$request->get('userComment')) {
//            return $this->render('SiteBlogBundle:Blog:setPostComment.html.twig');
//        }
                
        //$datetime = new \DateTime('now');
        
        $em = $this->get('doctrine')->getManager();
        $user = $this->get('security.context')->getToken()->getUser();
//        $userId = $user->getID();
//        $userProfile = $em->getRepository('BundlesUserBundle:User') -> findOneBy(['id' => $userId]); 
        
        $editUserProfile->setUserName($request->get('userName')); 
        $editUserProfile->setFirstName($request->get('userFirstName'));
        $editUserProfile->setLastName($request->get('userLastName'));
        $editUserProfile->setEmail($request->get('userEmail'));
        //$editUserProfile->setDatetime($datetime);
        //$editUserProfile->setBlog($blog);
              
        $em->persist($editUserProfile);
        $em->flush();
     
        
        return $this->render('BundlesUserBundle:UserProfile:editProfile.html.twig', ['user' => $user]);
    }

    
}