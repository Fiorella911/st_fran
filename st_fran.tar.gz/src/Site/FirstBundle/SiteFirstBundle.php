<?php

namespace Site\FirstBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SiteFirstBundle extends Bundle
{
}
