<?php

namespace Site\BlogBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SiteBlogBundle extends Bundle
{
}
