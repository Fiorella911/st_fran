<?php

namespace Site\NewsBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SiteNewsBundle extends Bundle
{
}
